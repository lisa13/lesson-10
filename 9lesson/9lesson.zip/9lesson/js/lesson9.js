//*************************************************************TEST ANSWERS */
// Write a JavaScript program to construct the following pattern, using a nested for loop.

var x;
var y;
var chr;

for(x=1; x <=6; x++)
{
   for (y=1; y < x; y++)
     {
    chr += ("*");        
      }
 console.log(chr);
 chr='';    
}
//--------------or

for(var i = 1; i < 6; i++) {
console.log("* ".repeat(i));
}
//-----------------------------------
//Write a JavaScript program to get the current date.
//mm-dd-yyyy, mm/dd/yyyy or dd-mm-yyyy, dd/mm/yyyy


var today = new Date();
var dd = today.getDate();

var mm = today.getMonth()+1; 
var yyyy = today.getFullYear();
if(dd<10) 
{
    dd='0'+dd;
} 

if(mm<10) 
{
    mm='0'+mm;
} 
today = mm+'-'+dd+'-'+yyyy;
console.log(today);
today = mm+'/'+dd+'/'+yyyy;
console.log(today);
console.log(today);
today = dd+'-'+mm+'-'+yyyy;
console.log(today);
today = dd+'/'+mm+'/'+yyyy;
console.log(today);

//-------------------------------------------
//Loop over the count array and log out the last three items to the console.

var count = ["one","two","three","four","five"];


for (var i=0; i<count.length; i++) {
        if (count.length-i <= 3) {
            console.log(count[i]);
    }
}

//-------------------------------------------------

//Arrays of arrays
var newArray =[[[1], [2], [3]],[[1], [2], [3]],[[1], [2], [3]]];
console.log(newArray);

//Heterogeneous arrays
var myArray =[13, true, "life"];

//jagged arrays
var jagged = [[[1],[2],['string']],[true],[13]];


var objectName = {
    member1Name: member1Value,
    member2Name: member2Value,
    member3Name: member3Value
}

//An empty object (“empty cabinet”) can be created using one of two syntaxes:

var user = new Object(); // "object constructor" syntax
var user = {};  // "object literal" syntax

//We can immediately put some properties into {...} as “key: value” pairs:
//The resulting user object can be imagined as a cabinet with two signed files labelled “name” and “age”.

var user = {     // an object
  name: "John",  // by key "name" store value "John"
  age: 30        // by key "age" store value 30
};

//We can add, remove and read files from it any time. Property values are accessible using the dot notation:
alert( user.name ); // John
console.log( user.age ); // 30

//The value can be of any type, add a boolean and a string:

user.isAdmin = true;
user.secondName = "Doe";

// now lets delete user.age;
delete user.age;
console.log(user);
//------------------The last property in the list may end with a comma:
//That is called a “trailing” or “hanging” comma. Makes it easier to add/remove/move around properties
var user = {
  name: "John",
  age: 30,
}



//-------------------------------------------------------------
var person = {
    firstName: "John",
    lastName: "Doe",
    age: 50,
    eyeColor: "blue"
};

console.log(person);
console.log(person.lastName)

//-----------------------or------------------
var person = new Object()

person.firstName = "John";
person.lastName = "John";
person.age = 50;
person.eyeColor = "blue";

console.log(person);
console.log(person.lastName)

//---------------------------------------------

var book = new Object();   
book.subject = "JS ROCKS!";
book.author = "No Idea";

console.log("Book's name is : " + book.subject);
console.log("Book's author is : " + book.author);

//---------------------------- UPDATING OBJECTS
var myDog = {
  "name": "Coder",
  "legs": 4,
  "tails": 1,
  "friends": ["Free Code Camp Campers"]
};

myDog.name ='Happy Coder';

//--------------If the property of the object we are trying to access has a space in it, we must use bracket notation.

var testObj = {
  "for starers": "salad",
  "my drink": "slurpy",
  "devine desert": "nutella",
};
testObj["check please"] = "whatever"

console.log(testObj["my drink"]);

var firstOrder = testObj['for starers'];   
var secOrder = testObj["my drink"];

console.log(secOrder);
//---------------------------------------

//-------------------------------------------- Functions next------------------------